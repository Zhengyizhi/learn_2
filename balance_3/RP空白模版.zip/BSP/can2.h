#ifndef __CAN2_H__
#define __CAN2_H__

#include "system.h"

void CAN2_Init(void);
void CAN2_Send_RM2006_Motor(void);

#endif 
